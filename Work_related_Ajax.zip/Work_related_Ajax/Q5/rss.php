<?php
header ('Content-type: text/xml');
$feed=file_get_contents("news.xml");
echo $feed;
?>
