<?php 
	extract($_GET);
	$file = fopen("seatInfo.txt", "r");
    
	while (!feof($file) ) {
	   $line_of_text = fgets($file);
	   $parts = explode(';', trim($line_of_text));
     }
    if($college=="pesit"){
    	if($branch=="ec"){
    		$parts[0]-=1;
    	}
    	else{
    		$parts[1]-=1;
    	}
    }
    if($college=="rv"){
		if($branch=="ec"){
			$parts[2]-=1;
    	}
    	else{
    		$parts[3]-=1;
    	}
    }
   fclose($file);
   // print json_encode($parts);
   // $file = fopen("seatInfo.txt", "w");
   // echo fwrite($file,$json_encode($parts));
   array($parts);
   implode(";",$parts);
   $file = fopen("seatInfo.txt", "w");
   fwrite($file,implode(";",$parts));
   echo implode(";",$parts);

?>