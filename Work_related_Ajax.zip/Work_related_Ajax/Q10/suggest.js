function Suggest()
{
	othis = this;
	this.player = null;
	this.container = null;
	this.id = null; // For controlling the timer
	
	//Create the XHR for making the request
	this.xhr = new XMLHttpRequest();
	
	//The function to create the timer for making the server request
	this.getPlayers = function()
	{	
		if(othis.id)
		{
			clearTimeout(othis.id);
		}
	
		othis.id = setTimeout(othis.fetchPlayers, 1000);
	};
	
	//The function that will actually make the request to the server
	// and fetch the suggestions
	
	this.fetchPlayers = function()
	{
		othis.player = document.getElementById("plpart");
		othis.container = document.getElementById("container");
	
		//How can we have a keyup and the text box has NO chars in it?????
		if(othis.player.value == "")
		{
			//return. There is nothing to do
			othis.container.style.display = "none";
			othis.container.innerHTML = "";
		
		}
		
		else
		{
			//The user typed something. We need to put some code here to 
			// make the fetch efficient. Leave space for some code we will
			// add later on
			//if(inbrowsercache)
			{
				//Show from cache;
			}
			//else
			{
				//Make the connection to the server
				othis.xhr.onreadystatechange = othis.showPlayers;
				
				//Open a GET connection
				othis.xhr.open("GET", "http://localhost/web2017/sub/late/getplayers.php?pl=" + othis.player.value, true);
		
				//Send the request
				othis.xhr.send();
			
			}
		}
	};
	
	//The function to populate the container div with the suggestions
	this.showPlayers = function()
	{
		if(othis.xhr.readyState == 4 && othis.xhr.status == 200)
		{
			var players = JSON.parse(othis.xhr.responseText);
			if(players.length == 0)
			{
				//Clear the container div
				othis.container.innerHTML = "";
				othis.container.style.display = "none";
			
				//Change style so that the user has some indication
				othis.player.className = "notfound";
			}
			else 
			{
				//We have some suggestions. Create divs and populate them
				// and append them to the container
				othis.container.innerHTML = "";
				
				othis.player.className = "found";
				
				for(var j=0;j < players.length; j++)
				{
					var newdiv = document.createElement("div");
					newdiv.innerHTML = players[j];
			
					newdiv.className = "suggested";
					
					//Now append
					othis.container.appendChild(newdiv);
					
					//Now register the onclick event for the newdiv
					newdiv.onclick = othis.setPlayer;
			
				}
				
				//Set the container's display to block so that it is seen
				othis.container.style.display = "block";
			}
		}
	};
	
	this.setPlayer = function(event)
	{
		othis.player.value = event.target.innerHTML;
		othis.container.style.display = "none";
		othis.container.innerHTML = "";	
	
	};
}


obj = new Suggest();