<?php
	
	//Get the playerpart from the request
	extract($_GET);
	
	//Create an array to store the matches
	$players = array();
	
	//Open the file to read the data
	$file = fopen("Players.txt", "r");
	
	while($line = fgets($file))
	{
		$player = trim($line);
	
		//Compare the player part sent by the client with the player
		// got from the file
		if(strncasecmp($player, $pl, strlen($pl)) == 0)
		{
			$players[] = $player;
		}
	}
	
	//Now we have the array.  JSON-ify the array and send it.
	$retobj = json_encode($players);
	
	echo $retobj;
	
	
	
?>