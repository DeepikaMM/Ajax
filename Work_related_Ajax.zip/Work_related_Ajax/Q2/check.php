<html>
<head>
<script>
<?php
  extract($_GET);
  $file=fopen("student.txt","r");

while($line=fgets($file))
{
 $modline=trim($line);
 $arr=explode(";",$modline);
 $found=false;
 if($un==$arr[0])
 {
  $found=true;
  break;
 }
}
if($found==true)
{
  echo 'parent.update("'.$modline.'");'; 
}
else
{
  echo 'parent.notfnd("USN not found");';
}
?>
</script>
</head>
<body>

</body>
</html>
