<?php
extract($_GET);
$f=fopen("saved.txt","w");
fwrite($f,$cmt);
fclose($f);
echo "Done";
?>