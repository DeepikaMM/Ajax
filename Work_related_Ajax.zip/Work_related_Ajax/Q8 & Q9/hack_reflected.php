<?php
extract($_GET);

echo "Congradulations ".$name." !!! <br>You have been hacked :D";
?>