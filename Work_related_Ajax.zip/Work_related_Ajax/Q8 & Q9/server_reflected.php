<?php
extract($_GET);
echo "<p id='a'> ";
echo "Hi ".$name;
echo "</p>";
//echo $txtSearch;
?>