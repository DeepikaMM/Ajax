<?php
//$file=fopen("cmt.txt","r");
echo file_get_contents("saved.txt");
?>