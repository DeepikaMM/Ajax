<?php
	header("Content-type:text/event-stream");
	ob_start();
	$oldtimeA=filemtime("chatA.txt");
	$oldtimeB=filemtime("chatB.txt");
	
while(true)
{ 
		clearstatcache();
	$newtimeA=filemtime("chatA.txt");
	$newtimeB=filemtime("chatB.txt");
	
	echo "event:received\n";
		//Automatic retry occurs every 3 seconds. The line below changes it to 10 s.
		echo "retry:10000\n";
		//Last line must end with two \n 
	if($newtimeA>$oldtimeA){
		clearstatcache();
		$sendA=file_get_contents("chatA.txt");
		$resA=explode("\n",$sendA);
		$rA=sizeof($resA)-1;
		echo "data:<h2>A: $resA[$rA]</h2>\n\n";
		ob_flush();
		flush();
		$oldtimeA=$newtimeA;
		
		}
		if($newtimeB>$oldtimeB){
		clearstatcache();
		$sendB=file_get_contents("chatB.txt");
		$resB=explode("\n",$sendB);
		$rB=sizeof($resB)-1;
		echo "data:<h2>B: $resB[$rB]</h2>\n\n";
		ob_flush();
		flush();
		$oldtimeB=$newtimeB;
		
		}
		sleep(4);
}
?>